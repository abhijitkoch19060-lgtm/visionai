import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Power, PowerOff, ShieldAlert, Activity, Settings2 } from "lucide-react";

// Types for window globals loaded via CDN
declare global {
  interface Window {
    tf: any;
    cocoSsd: any;
  }
}

// Configuration from original code, tweaked for accessibility
const CONFIG = {
  CONFIDENCE_MIN: 0.50,
  FPS_THROTTLE: 1000 / 5, // Process 5 frames a second to save battery, blind user doesn't need 30fps screen updates, they need audio
  AUDIO_COOLDOWN: 5000,   // Don't repeat the same object within 5 seconds
};

export default function Home() {
  const [isBooting, setIsBooting] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [status, setStatus] = useState("System Offline. Press Start to begin navigation.");
  const [logs, setLogs] = useState<string[]>([]);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // State refs for the vision loop
  const modelRef = useRef<any>(null);
  const lastFrameTimeRef = useRef<number>(0);
  const objectHistoryRef = useRef<Map<string, number>>(new Map());
  const requestRef = useRef<number>(null);
  const isDetectingRef = useRef(false);

  // Audio Engine Refs
  const synthRef = useRef<SpeechSynthesis>(window.speechSynthesis);
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null);
  
  // Keep ref synced for the loop
  useEffect(() => {
    isDetectingRef.current = isDetecting;
  }, [isDetecting]);

  const addLog = useCallback((msg: string) => {
    setLogs(prev => [msg, ...prev].slice(0, 5));
  }, []);

  const initAudio = useCallback(() => {
    const setVoice = () => {
      const voices = synthRef.current.getVoices();
      voiceRef.current = 
        voices.find(v => v.name.includes('Google US English')) || 
        voices.find(v => v.lang === 'en-US') || 
        voices[0] || null;
    };
    synthRef.current.onvoiceschanged = setVoice;
    setVoice();
  }, []);

  useEffect(() => {
    initAudio();
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      if (synthRef.current) synthRef.current.cancel();
      stopCamera();
    };
  }, [initAudio]);

  const speak = useCallback((text: string, priority: boolean = false) => {
    if (!text || !synthRef.current) return;
    
    if (priority) {
      synthRef.current.cancel();
    } else if (synthRef.current.speaking) {
      // If non-priority and already speaking, skip to avoid overwhelm
      return; 
    }

    const utterance = new SpeechSynthesisUtterance(text);
    if (voiceRef.current) utterance.voice = voiceRef.current;
    utterance.rate = 1.1;
    utterance.pitch = 1;
    synthRef.current.speak(utterance);
    addLog(`Speaking: "${text}"`);
  }, [addLog]);

  const processPredictions = useCallback((predictions: any[]) => {
    if (!canvasRef.current || !videoRef.current) return;
    
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    const validTargets = predictions.filter((p: any) => p.score > CONFIG.CONFIDENCE_MIN);
    
    const width = canvasRef.current.width;
    const now = Date.now();
    let spokenThisFrame = false;

    validTargets.forEach((target: any) => {
      const [x, y, w, h] = target.bbox;
      
      // Draw for sighted assistant/debug
      ctx.strokeStyle = '#FFD600'; // High contrast yellow
      ctx.lineWidth = 6;
      ctx.strokeRect(x, y, w, h);
      
      ctx.fillStyle = '#FFD600';
      ctx.font = '24px Inter';
      ctx.fillText(`${target.class} ${Math.round(target.score * 100)}%`, x, y > 30 ? y - 10 : y + 30);

      // Determine position
      const centerX = x + w / 2;
      let position = "straight ahead";
      if (centerX < width * 0.33) position = "on the left";
      else if (centerX > width * 0.66) position = "on the right";

      // Throttle audio per object class
      const historyKey = `${target.class}-${position}`;
      const lastSpoken = objectHistoryRef.current.get(historyKey) || 0;
      
      // Very crude distance estimation based on size ratio
      const fillRatio = (w * h) / (canvasRef.current.width * canvasRef.current.height);
      const isClose = fillRatio > 0.25;

      if (now - lastSpoken > CONFIG.AUDIO_COOLDOWN && !spokenThisFrame) {
        objectHistoryRef.current.set(historyKey, now);
        const warning = isClose ? `Warning! ${target.class} close ${position}.` : `${target.class} ${position}.`;
        speak(warning, isClose);
        spokenThisFrame = true; // Only speak one object per frame to prevent babbling
      }
    });
  }, [speak]);

  const visionLoop = useCallback((timestamp: number) => {
    if (!isDetectingRef.current) return;

    if (timestamp - lastFrameTimeRef.current >= CONFIG.FPS_THROTTLE) {
      if (videoRef.current && videoRef.current.readyState === 4 && modelRef.current) {
        modelRef.current.detect(videoRef.current).then(processPredictions);
        lastFrameTimeRef.current = timestamp;
      }
    }
    requestRef.current = requestAnimationFrame(visionLoop);
  }, [processPredictions]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          if (canvasRef.current && videoRef.current) {
            canvasRef.current.width = videoRef.current.videoWidth;
            canvasRef.current.height = videoRef.current.videoHeight;
          }
        };
      }
    } catch (err) {
      console.error(err);
      setStatus("Camera access denied or failed.");
      speak("Camera access failed. Please check permissions.", true);
      throw err;
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const bootSystem = async () => {
    if (isBooting || isDetecting) return;
    
    setIsBooting(true);
    setStatus("Initializing AI. Please wait...");
    speak("Initializing Navigation AI. Please hold the phone facing forward.", true);

    try {
      if (!window.tf || !window.cocoSsd) {
        throw new Error("AI libraries not loaded");
      }

      await window.tf.setBackend('webgl');
      await window.tf.ready();
      
      modelRef.current = await window.cocoSsd.load();
      await startCamera();

      setIsBooting(false);
      setIsDetecting(true);
      setStatus("System Active. Scanning environment.");
      speak("Navigation started. I will announce objects around you.", true);
      
      requestRef.current = requestAnimationFrame(visionLoop);

    } catch (err) {
      console.error(err);
      setIsBooting(false);
      setStatus("System failure. Retrying recommended.");
      speak("Failed to start the AI. Please try again.", true);
    }
  };

  const haltSystem = () => {
    setIsDetecting(false);
    setStatus("Navigation paused.");
    speak("Navigation paused.", true);
    stopCamera();
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 flex flex-col font-sans selection:bg-primary selection:text-black">
      {/* HEADER */}
      <header className="mb-6 flex flex-col gap-2 border-b-4 border-primary pb-4">
        <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tight text-white flex items-center gap-3" aria-label="Vision Assist Application">
          <ShieldAlert className="w-10 h-10 md:w-14 md:h-14 text-primary" aria-hidden="true" />
          Vision Assist
        </h1>
        <p className="text-xl md:text-2xl font-bold text-primary" aria-live="polite">
          {status}
        </p>
      </header>

      {/* MAIN CONTROLS - Massive for low-vision/motor access */}
      <main className="flex-1 flex flex-col gap-6 w-full max-w-3xl mx-auto">
        {!isDetecting ? (
          <Button 
            onClick={bootSystem} 
            disabled={isBooting}
            className="w-full h-48 md:h-64 text-4xl md:text-5xl bg-primary hover:bg-yellow-400 text-black font-black uppercase border-4 border-transparent focus:border-white focus:ring-4 focus:ring-primary rounded-xl transition-all active:scale-95"
            aria-label="Start Navigation Mode"
          >
            {isBooting ? (
              <span className="flex items-center gap-4 animate-pulse">
                <Settings2 className="w-12 h-12 animate-spin" />
                Loading AI...
              </span>
            ) : (
              <span className="flex items-center gap-4">
                <Power className="w-16 h-16" />
                Start Navigation
              </span>
            )}
          </Button>
        ) : (
          <Button 
            onClick={haltSystem}
            className="w-full h-48 md:h-64 text-4xl md:text-5xl bg-red-600 hover:bg-red-500 text-white font-black uppercase border-4 border-transparent focus:border-white focus:ring-4 focus:ring-red-600 rounded-xl transition-all active:scale-95"
            aria-label="Stop Navigation Mode"
          >
            <span className="flex items-center gap-4">
              <PowerOff className="w-16 h-16" />
              Stop Navigation
            </span>
          </Button>
        )}

        {/* LOGS / AUDIO FEEDBACK DISPLAY */}
        <Card className="bg-zinc-900 border-4 border-zinc-700 p-6 rounded-xl flex flex-col gap-4 shadow-xl">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <Activity className="text-primary w-8 h-8" />
            Audio Logs
          </h2>
          <div 
            className="flex flex-col gap-3 min-h-[150px]" 
            aria-live="assertive" 
            aria-atomic="true"
          >
            {logs.length === 0 ? (
              <p className="text-zinc-400 text-xl font-medium">No objects announced yet.</p>
            ) : (
              logs.map((log, i) => (
                <div key={i} className={`text-2xl font-bold ${i === 0 ? 'text-primary' : 'text-zinc-500'}`}>
                  {log}
                </div>
              ))
            )}
          </div>
        </Card>

        {/* CAMERA FEED - Visually hidden but structurally present, or shown small for sighted assistance */}
        <div className={`relative overflow-hidden rounded-xl border-4 ${isDetecting ? 'border-primary' : 'border-zinc-800'} bg-black aspect-video flex-shrink-0 w-full md:w-3/4 mx-auto`} aria-hidden="true">
          {!isDetecting && !isBooting && (
             <div className="absolute inset-0 flex items-center justify-center text-zinc-600 text-2xl font-bold">
               Camera Offline
             </div>
          )}
          <video 
            ref={videoRef} 
            className="absolute inset-0 w-full h-full object-cover"
            playsInline 
            autoPlay 
            muted 
          />
          <canvas 
            ref={canvasRef} 
            className="absolute inset-0 w-full h-full object-cover z-10"
          />
        </div>
      </main>
    </div>
  );
}
